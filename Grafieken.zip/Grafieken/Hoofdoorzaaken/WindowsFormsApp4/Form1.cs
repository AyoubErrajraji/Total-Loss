﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void chart1_Click(object sender, EventArgs e)
        {
            this.Oorzaken.Series["ongelukken"].Points.AddXY("aanrijding auto", 500);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("in water gereden", 50);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("aanrijding fietser", 25);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("rijden onder alcohol infloed", 100);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("rijden onder drug infloed", 200);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("ongeluk door het weer", 350);
        }
    }
}
