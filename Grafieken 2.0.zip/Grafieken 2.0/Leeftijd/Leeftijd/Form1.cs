﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            chart1_Click(null, null);

        }

        private void chart1_Click(object sender, EventArgs e)
        {
            this.chart1.Series["leeftijd"].Points.Clear();

            this.chart1.Series["leeftijd"].Points.AddXY("18-25", 100);
            this.chart1.Series["leeftijd"].Points.AddXY("26-35", 50);
            this.chart1.Series["leeftijd"].Points.AddXY("36-65", 25);
            this.chart1.Series["leeftijd"].Points.AddXY("66+", 100);

            this.chart1.Series[0].IsValueShownAsLabel = true;
            this.chart1.ChartAreas[0].AxisX.Title = "Leeftijd";
            this.chart1.ChartAreas[0].AxisY.Title = "Gewonden";

            
        }
    }
}
