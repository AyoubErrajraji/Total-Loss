﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            chart1_Click(null, null);
        }

        private void chart1_Click(object sender, EventArgs e)
        {
            this.Oorzaken.Series["ongelukken"].Points.Clear();

            //the inserts for the graph (VERANDER ALLEEN DIT!)
            this.Oorzaken.Series["ongelukken"].Points.AddXY("aanrijding auto", 500);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("in water gereden", 50);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("aanrijding fietser", 25);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("rijden onder alcohol infloed", 100);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("rijden onder drug infloed", 200);
            this.Oorzaken.Series["ongelukken"].Points.AddXY("ongeluk door het weer", 350);

            //Axis names
            this.Oorzaken.Series[0].IsValueShownAsLabel = true;
            this.Oorzaken.ChartAreas[0].AxisX.Title = "Oorzaken ongelukken";
            this.Oorzaken.ChartAreas[0].AxisY.Title = "Aantal slachtoffers";

        }
    }
}
