﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            chart2_Click(null, null);
        }

        
        private void chart2_Click(object sender, EventArgs e)
        {
            //reset your chart series and legends
            chart2.Series.Clear();
            chart2.Legends.Clear();

            //Add a new Legend(if needed) and do some formating
            chart2.Legends.Add("MyLegend");
            chart2.Legends[0].LegendStyle = LegendStyle.Table;
            chart2.Legends[0].Docking = Docking.Bottom;
            chart2.Legends[0].Alignment = StringAlignment.Center;
            chart2.Legends[0].Title = "ongelukken op nationaliteit";
            chart2.Legends[0].BorderColor = Color.Black;

            //Add a new chart-series
            string seriesname = "MySeriesName";
            chart2.Series.Add(seriesname);
            //set the chart-type to "Pie"
            chart2.Series[seriesname].ChartType = SeriesChartType.Pie;

            //Add some datapoints so the series. in this case you can pass the values to this method
            //series stats (VERANDER ALLEEN DIT!)
            chart2.Series[seriesname].Points.AddXY("13%", 13);
            chart2.Series[seriesname].Points.AddXY("15%", 15);
            chart2.Series[seriesname].Points.AddXY("7%", 7);
            chart2.Series[seriesname].Points.AddXY("55%", 55);
            chart2.Series[seriesname].Points.AddXY("8%", 8);
            chart2.Series[seriesname].Points.AddXY("12%", 12);

            //series names (VERANDER ALLEEN DIT!)
            chart2.Series[seriesname].Points[0].LegendText = "Belg";
            chart2.Series[seriesname].Points[1].LegendText = "Duitser";
            chart2.Series[seriesname].Points[2].LegendText = "Frans";
            chart2.Series[seriesname].Points[3].LegendText = "Pols";
            chart2.Series[seriesname].Points[4].LegendText = "Deens";
            chart2.Series[seriesname].Points[5].LegendText = "Overig";
        }
    }
}
